package com.example.parkingbookingapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.parkingbookingapp.data.repository.ParkingRepository
import com.example.parkingbookingapp.navigation.AppNavigation
import com.example.parkingbookingapp.ui.viewmodel.MainViewModel
import com.example.parkingbookingapp.ui.viewmodel.MainViewModelFactory
import com.example.parkingbookingapp.ui.theme.ParkingBookingAppTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels {
        MainViewModelFactory(ParkingRepository())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ParkingBookingAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation(viewModel)
                }
            }
        }
    }
}