package com.example.parkingbookingapp.data.repository

import com.example.parkingbookingapp.data.model.Booking
import com.example.parkingbookingapp.data.model.ParkingSpot
import com.example.parkingbookingapp.data.model.ParkingSpotPosition
import java.util.Calendar
import java.util.Date

class ParkingRepository {
    private val parkingSpots = mutableListOf<ParkingSpot>()

    init {
        // Инициализация 36 парковочных мест (10 left, 10 right, 10 center top, 6 bottom)
        for (i in 1..10) {
            parkingSpots.add(createParkingSpot(i, "L$i", ParkingSpotPosition.LEFT))
            parkingSpots.add(createParkingSpot(i + 10, "R$i", ParkingSpotPosition.RIGHT))

            if (i <= 5) {
                parkingSpots.add(createParkingSpot(i + 20, "CT$i", ParkingSpotPosition.CENTER_TOP))
                parkingSpots.add(createParkingSpot(i + 25, "CB$i", ParkingSpotPosition.CENTER_BOTTOM))
            }

            if (i <= 6) {
                parkingSpots.add(createParkingSpot(i + 30, "B$i", ParkingSpotPosition.BOTTOM))
            }
        }
    }

    private fun createParkingSpot(id: Int, name: String, position: ParkingSpotPosition): ParkingSpot {
        return ParkingSpot(
            id = id,
            name = name,
            isAvailable = true,
            position = position
        )
    }

    fun getParkingSpots(): List<ParkingSpot> = parkingSpots

    fun getParkingSpotById(id: Int): ParkingSpot? = parkingSpots.find { it.id == id }

    fun bookParkingSpot(spotId: Int, carNumber: String, hours: Int): Boolean {
        val spot = parkingSpots.find { it.id == spotId && it.isAvailable } ?: return false

        val calendar = Calendar.getInstance()
        val startTime = calendar.time
        calendar.add(Calendar.HOUR, hours)
        val endTime = calendar.time

        val updatedSpot = spot.copy(
            isAvailable = false,
            booking = Booking(carNumber, startTime, endTime)
        )

        val index = parkingSpots.indexOfFirst { it.id == spotId }
        if (index != -1) {
            parkingSpots[index] = updatedSpot
            return true
        }

        return false
    }
}