package com.example.parkingbookingapp.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.parkingbookingapp.ui.screens.BookingScreen
import com.example.parkingbookingapp.ui.screens.MainScreen
import com.example.parkingbookingapp.ui.screens.SpotDetailsScreen
import com.example.parkingbookingapp.ui.viewmodel.MainViewModel

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "main"
    ) {
        composable("main") {
            MainScreen(
                viewModel = viewModel,
                onSpotClick = { spotId, isAvailable ->
                    if (isAvailable) {
                        navController.navigate("booking/$spotId")
                    } else {
                        navController.navigate("details/$spotId")
                    }
                }
            )
        }

        composable("booking/{spotId}") { backStackEntry ->
            val spotId = backStackEntry.arguments?.getString("spotId")?.toIntOrNull() ?: -1
            BookingScreen(
                spotId = spotId,
                onBack = { navController.popBackStack() }
            )
        }

        composable("details/{spotId}") { backStackEntry ->
            val spotId = backStackEntry.arguments?.getString("spotId")?.toIntOrNull() ?: -1
            SpotDetailsScreen(
                spotId = spotId,
                onBack = { navController.popBackStack() }
            )
        }
    }
}