package com.example.parkingbookingapp.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.parkingbookingapp.data.model.ParkingSpot
import com.example.parkingbookingapp.data.model.ParkingSpotPosition

@Composable
fun ParkingSpotComponent(
    spot: ParkingSpot,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (spot.isAvailable) Color.Green else Color.Red,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(4.dp),
        modifier = modifier.size(
            width = if (spot.position.isVertical()) 40.dp else 80.dp,
            height = if (spot.position.isVertical()) 80.dp else 40.dp
        )
    ) {
        Text(text = spot.name)
    }
}

private fun ParkingSpotPosition.isVertical(): Boolean {
    return this == ParkingSpotPosition.CENTER_TOP ||
            this == ParkingSpotPosition.CENTER_BOTTOM ||
            this == ParkingSpotPosition.BOTTOM
}