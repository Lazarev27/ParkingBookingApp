package com.example.parkingbookingapp.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.parkingbooking.R
import com.example.parkingbookingapp.data.model.ParkingSpot
import com.example.parkingbookingapp.ui.components.ParkingSpotComponent
import com.example.parkingbookingapp.ui.viewmodel.MainViewModel

@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onSpotClick: (Int, Boolean) -> Unit
) {
    val parkingSpots = viewModel.parkingSpots.collectAsState().value
    val leftSpots = parkingSpots.filter { it.position == ParkingSpotPosition.LEFT }
    val rightSpots = parkingSpots.filter { it.position == ParkingSpotPosition.RIGHT }
    val centerTopSpots = parkingSpots.filter { it.position == ParkingSpotPosition.CENTER_TOP }
    val centerBottomSpots = parkingSpots.filter { it.position == ParkingSpotPosition.CENTER_BOTTOM }
    val bottomSpots = parkingSpots.filter { it.position == ParkingSpotPosition.BOTTOM }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Парковочные места",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp)
        )

        Image(
            painter = painterResource(id = R.drawable.parking_lot_background),
            contentDescription = "Parking lot",
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .padding(horizontal = 16.dp)
        )

        // Левая сторона (10 мест горизонтально)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.Start
        ) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(leftSpots) { spot ->
                    ParkingSpotComponent(
                        spot = spot,
                        onClick = { onSpotClick(spot.id, spot.isAvailable) }
                    )
                }
            }
        }

        // Правая сторона (10 мест горизонтально)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.End
        ) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(rightSpots) { spot ->
                    ParkingSpotComponent(
                        spot = spot,
                        onClick = { onSpotClick(spot.id, spot.isAvailable) }
                    )
                }
            }
        }

        // Центр (10 мест вертикально в 2 ряда)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Верхний ряд центра
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                centerTopSpots.forEach { spot ->
                    ParkingSpotComponent(
                        spot = spot,
                        onClick = { onSpotClick(spot.id, spot.isAvailable) }
                    )
                }
            }

            // Нижний ряд центра
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(start = 16.dp)
            ) {
                centerBottomSpots.forEach { spot ->
                    ParkingSpotComponent(
                        spot = spot,
                        onClick = { onSpotClick(spot.id, spot.isAvailable) }
                    )
                }
            }
        }

        // Нижняя часть (6 мест вертикально)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(bottomSpots) { spot ->
                    ParkingSpotComponent(
                        spot = spot,
                        onClick = { onSpotClick(spot.id, spot.isAvailable) }
                    )
                }
            }
        }
    }
}