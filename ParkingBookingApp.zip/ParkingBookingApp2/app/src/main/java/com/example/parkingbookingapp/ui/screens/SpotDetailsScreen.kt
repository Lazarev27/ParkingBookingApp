package com.example.parkingbookingapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.parkingbookingapp.data.model.ParkingSpot
import com.example.parkingbookingapp.ui.viewmodel.SpotDetailsViewModel
import com.example.parkingbookingapp.ui.viewmodel.SpotDetailsViewModelFactory
import com.example.parkingbookingapp.data.repository.ParkingRepository
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun SpotDetailsScreen(
    spotId: Int,
    onBack: () -> Unit
) {
    val viewModel: SpotDetailsViewModel = viewModel(
        factory = SpotDetailsViewModelFactory(ParkingRepository(), spotId)
    )
    val spot by viewModel.parkingSpot.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Информация о месте $spotId",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        spot?.let {
            if (!it.isAvailable && it.booking != null) {
                val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
                val timeLeft = (it.booking.endTime.time - System.currentTimeMillis()) / (60 * 60 * 1000)

                Text(
                    text = "Автомобиль: ${it.booking.carNumber}",
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Время брони: ${
                        dateFormat.format(it.booking.startTime)
                    } - ${
                        dateFormat.format(it.booking.endTime)
                    }",
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Осталось: $timeLeft ч.",
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Text(text = "Место свободно")
            }
        }

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Назад")
        }
    }
}