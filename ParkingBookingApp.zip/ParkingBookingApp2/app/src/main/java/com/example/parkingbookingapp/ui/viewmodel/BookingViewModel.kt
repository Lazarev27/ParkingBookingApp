package com.example.parkingbookingapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.parkingbookingapp.data.repository.ParkingRepository
import kotlinx.coroutines.launch

class BookingViewModel(
    private val repository: ParkingRepository,
    private val spotId: Int
) : ViewModel() {
    fun bookSpot(carNumber: String, hours: Int) {
        viewModelScope.launch {
            repository.bookParkingSpot(spotId, carNumber, hours)
        }
    }
}