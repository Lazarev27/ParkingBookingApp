package com.example.parkingbookingapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.parkingbookingapp.data.model.ParkingSpot
import com.example.parkingbookingapp.data.repository.ParkingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel(private val repository: ParkingRepository) : ViewModel() {
    private val _parkingSpots = MutableStateFlow<List<ParkingSpot>>(emptyList())
    val parkingSpots: StateFlow<List<ParkingSpot>> = _parkingSpots

    init {
        loadParkingSpots()
    }

    private fun loadParkingSpots() {
        viewModelScope.launch {
            _parkingSpots.value = repository.getParkingSpots()
        }
    }

    fun refreshData() {
        loadParkingSpots()
    }
}