package com.example.parkingbookingapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.parkingbookingapp.data.model.ParkingSpot
import com.example.parkingbookingapp.data.repository.ParkingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SpotDetailsViewModel(
    private val repository: ParkingRepository,
    private val spotId: Int
) : ViewModel() {
    private val _parkingSpot = MutableStateFlow<ParkingSpot?>(null)
    val parkingSpot: StateFlow<ParkingSpot?> = _parkingSpot

    init {
        loadParkingSpot()
    }

    private fun loadParkingSpot() {
        viewModelScope.launch {
            _parkingSpot.value = repository.getParkingSpotById(spotId)
        }
    }
}