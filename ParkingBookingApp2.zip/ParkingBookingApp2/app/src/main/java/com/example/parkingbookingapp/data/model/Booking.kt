package com.example.parkingbookingapp.data.model

import java.util.Date

data class Booking(
    val carNumber: String,
    val startTime: Date,
    val endTime: Date
)