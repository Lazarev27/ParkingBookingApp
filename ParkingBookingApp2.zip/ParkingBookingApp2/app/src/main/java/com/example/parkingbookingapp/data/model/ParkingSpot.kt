package com.example.parkingbookingapp.data.model

data class ParkingSpot(
    val id: Int,
    val name: String,
    val isAvailable: Boolean,
    val position: ParkingSpotPosition,
    val booking: Booking? = null
)

enum class ParkingSpotPosition {
    LEFT, RIGHT, CENTER_TOP, CENTER_BOTTOM, BOTTOM
}