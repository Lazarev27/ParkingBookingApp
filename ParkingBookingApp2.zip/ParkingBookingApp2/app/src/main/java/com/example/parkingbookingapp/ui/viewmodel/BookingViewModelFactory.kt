package com.example.parkingbookingapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.parkingbookingapp.data.repository.ParkingRepository

class BookingViewModelFactory(
    private val repository: ParkingRepository,
    private val spotId: Int
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BookingViewModel::class.java)) {
            return BookingViewModel(repository, spotId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}